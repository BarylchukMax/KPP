package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loadFragment(Fragment1())
        val buttonFragment1: Button = findViewById(R.id.buttonFragment1)
        val buttonFragment2: Button = findViewById(R.id.buttonFragment2)
        val buttonFragment3: Button = findViewById(R.id.buttonFragment3)

        buttonFragment1.setOnClickListener {
            loadFragment(Fragment1())
        }

        buttonFragment2.setOnClickListener {
            loadFragment(Fragment2())
        }

        buttonFragment3.setOnClickListener {
            loadFragment(Fragment3())
        }
    }

    private fun loadFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragmentContainer, fragment)
        transaction.commit()
    }
}