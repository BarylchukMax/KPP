package com.example.kpp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val textViewGroup: TextView = findViewById(R.id.editTextText)
        textViewGroup.text = "Група 4-6"
        textViewGroup.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        val buttonChangeText: Button = findViewById(R.id.button)
        buttonChangeText.setOnClickListener {
            val textViewName: TextView = findViewById(R.id.textView)
            textViewName.text = getString(R.string.barylchuk_maksym)
            textViewGroup.text = getString(R.string.group_4_6)
        }
    }
}