package com.example.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val emailAdrss: EditText = findViewById(R.id.emailAdrss)
        val emailSubject: EditText = findViewById(R.id.emailSubject)
        val emailMessage: EditText = findViewById(R.id.emailMessage)
        val sendEmailButton: Button = findViewById(R.id.sendEmailButton)
        sendEmailButton.setOnClickListener {
            val adress = emailAdrss.text.toString()
            val subject = emailSubject.text.toString()
            val message = emailMessage.text.toString()
            if (adress.isNotEmpty() && subject.isNotEmpty() && message.isNotEmpty()) {
                emailSending()
            } else {
                Toast.makeText(this, "Заповніть всі поля", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun emailSending() {
        val emailInfo = "Email відправлено"
        Toast.makeText(this, emailInfo, Toast.LENGTH_LONG).show()
    }
}