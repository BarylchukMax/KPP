package com.example.myapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val infoTextView: TextView = findViewById(R.id.infoTextView)
        val infoType = intent.getStringExtra("infoType")
        when (infoType) {
            "author" -> infoTextView.text = "Барильчук Максим"
            "faculty" -> infoTextView.text = "Факультет інформаційних технологій"
            "city" -> infoTextView.text = "Звягель"
        }
    }
}