package com.example.myapplication

import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.textView1.setOnClickListener {
            it as View
            binding.textView1.setTextColor(Color.RED)
        }
        binding.textView2.setOnClickListener {
            it as View
            binding.textView2.setTextColor(Color.GREEN)
        }
        binding.textView3.setOnClickListener {
            it as View
            binding.textView3.setTextColor(Color.BLUE)
        }
        binding.buttonHide.setOnClickListener {
            binding.textView1.visibility = View.INVISIBLE
        }
        binding.buttonShow.setOnClickListener {
            binding.textView1.visibility = View.VISIBLE
        }
    }
}