package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val randomNumber1: TextView = findViewById(R.id.randomNumber1)
        val randomNumber2: TextView = findViewById(R.id.randomNumber2)
        val resultSum: TextView = findViewById(R.id.resultSum)
        val resultDifference: TextView = findViewById(R.id.resultDifference)
        val sumButton: Button = findViewById(R.id.sumButton)
        val differenceButton: Button = findViewById(R.id.differenceButton)
        val num1 = Random.nextInt(0, 100)
        val num2 = Random.nextInt(0, 100)
        randomNumber1.text = num1.toString()
        randomNumber2.text = num2.toString()
        sumButton.setOnClickListener {
            val sum = num1 + num2
            resultSum.text = "Сума: $sum"
        }
        differenceButton.setOnClickListener {
            val difference = num1 - num2
            resultDifference.text = "Різниця: $difference"
        }
    }
}